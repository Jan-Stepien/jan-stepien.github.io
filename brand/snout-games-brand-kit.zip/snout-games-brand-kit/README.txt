Snout Games brand kit
Colours: Snout Black #1B1613, Snout Brown #B0602A, White #FFFFFF.
Keep clear space around the logo equal to the height of the S in SNOUT. Do not stretch, rotate, flip or recolour.
Guide: https://snoutgames.com/brand/  Contact: hello@snoutgames.com
